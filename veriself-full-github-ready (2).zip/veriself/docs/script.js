(() => {
  const repoUrl = 'https://github.com/keke2204/VERISELF';
  document.querySelectorAll('[data-repo]').forEach((link) => {
    link.setAttribute('href', repoUrl);
  });

  document.querySelectorAll('[data-compare-slider]').forEach((slider) => {
    const range = slider.querySelector('[data-compare-range]');
    const update = (value) => slider.style.setProperty('--position', `${value}%`);
    range?.addEventListener('input', (event) => update(event.target.value));
    update(range?.value || 50);
  });
})();
