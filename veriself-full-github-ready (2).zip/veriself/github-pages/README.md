# VeriSelf GitHub Pages Showcase

This folder is the human-designed static showcase UI for VeriSelf. It is an additional publishing layer and does not replace or modify the Next.js application or FastAPI backend.

## Publish from GitHub Pages

For the simplest setup, copy the contents of this folder into a `docs/` folder in the repository, so the entry point is `docs/index.html`. In GitHub, open **Settings → Pages**, choose **Deploy from a branch**, select the `main` branch and `/docs` folder, then save.

The GitHub repository link is already configured in `index.html` and `script.js`:

```text
https://github.com/keke2204/VERISELF
```

The page uses relative paths for CSS, JavaScript, and assets, so it works from a repository subpath such as `https://username.github.io/repository/`.

## Preview locally

From this folder:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080`. The static showcase itself has no backend dependency. The actual application continues to run through the FastAPI and Next.js services documented in the project root README.

## Included assets

The `assets/` folder contains existing cached project outputs: original, cloaked, and watermarked image variants.
