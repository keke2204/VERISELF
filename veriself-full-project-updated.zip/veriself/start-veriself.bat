@echo off
title VeriSelf - Biometric Identity Defense Platform
color 0b
echo ======================================================================
echo   VeriSelf Identity Defense Platform
echo   Launching FastAPI Engine (Port 8000) ^& Next.js Web App (Port 3000)
echo ======================================================================
echo.

cd /d "%~dp0apps\backend"
echo [1/3] Starting Python FastAPI Backend on http://127.0.0.1:8000 ...
start "VeriSelf Backend" cmd /k "python -m uvicorn main:app --host 127.0.0.1 --port 8000"

timeout /t 2 /nobreak >nul

cd /d "%~dp0apps\web"
echo [2/3] Starting Next.js Web Server on http://localhost:3000 ...
start "VeriSelf Frontend" cmd /k "npm run start -- -p 3000 -H 0.0.0.0"

timeout /t 3 /nobreak >nul

echo [3/3] Opening browser at http://localhost:3000 ...
start http://localhost:3000

echo.
echo ======================================================================
echo   VeriSelf is running!
echo   - Web UI: http://localhost:3000
echo   - Backend API: http://127.0.0.1:8000
echo   - API Docs: http://127.0.0.1:8000/docs
echo ======================================================================
pause
