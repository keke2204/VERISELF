@echo off
:: Batch script to set up veriself.local domain
echo ========================================================
echo   VeriSelf - Local Domain Setup (veriself.local)
echo ========================================================
echo.

:: Check for administrative permissions
net session >nul 2>&1
if %errorLevel% == 0 (
    echo [OK] Running with Administrator privileges.
) else (
    echo [!] Requesting Administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: Append to hosts file if not already present
findstr /C:"veriself.local" "%WINDIR%\System32\drivers\etc\hosts" >nul 2>&1
if %errorLevel% == 0 (
    echo [INFO] veriself.local is already configured in your hosts file.
) else (
    echo 127.0.0.1 veriself.local>>"%WINDIR%\System32\drivers\etc\hosts"
    echo 127.0.0.1 api.veriself.local>>"%WINDIR%\System32\drivers\etc\hosts"
    echo [SUCCESS] Added veriself.local to hosts file.
)

:: Flush DNS cache
ipconfig /flushdns >nul 2>&1

echo.
echo ========================================================
echo   Opening http://veriself.local:3000 in your browser...
echo ========================================================
start http://veriself.local:3000

pause
