@echo off
title VeriSelf - Platform Launcher
echo ========================================================
echo   Starting VeriSelf Identity Defense Platform
echo ========================================================
echo.

echo [1/2] Starting FastAPI Backend on port 8000...
start "VeriSelf Backend" /D "%~dp0apps\backend" python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload

echo [2/2] Starting Next.js Web Dashboard on port 3000...
start "VeriSelf Web" /D "%~dp0apps\web" npm run dev

echo.
echo ========================================================
echo   VeriSelf is running!
echo   Web App:  http://localhost:3000 (or http://veriself.local:3000)
echo   API Docs: http://localhost:8000/docs
echo ========================================================
timeout /t 3 >nul
start http://localhost:3000
