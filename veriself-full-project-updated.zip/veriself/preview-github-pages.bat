@echo off
title Preview VeriSelf GitHub Pages
echo =======================================================
echo   Previewing VeriSelf Static GitHub Pages Webpage
echo   Opening http://localhost:8080 in your browser...
echo =======================================================
start http://localhost:8080
cd /d "%~dp0github-pages"
python -m http.server 8080
pause
