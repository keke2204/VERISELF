import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-sans" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono" });

export const metadata: Metadata = {
  title: "VeriSelf — Biometric Defense & Forensic Identity Protection",
  description: "Enterprise digital identity defense engine. Adversarial pixel cloaking, perceptual hashing, deepfake analysis, and autonomous DMCA enforcement.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.variable} ${mono.variable} font-sans bg-[#09090b] text-zinc-100 min-h-screen antialiased selection:bg-zinc-800 selection:text-zinc-100`}>
        {/* Top Header */}
        <header className="border-b border-zinc-800/80 bg-[#09090b]/80 backdrop-blur-md sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-14">
              {/* Brand Logo */}
              <div className="flex items-center space-x-3">
                <div className="w-7 h-7 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center text-zinc-200 font-bold text-xs shadow-inner">
                  VS
                </div>
                <div className="flex items-center space-x-2">
                  <span className="font-semibold text-sm tracking-tight text-zinc-100">VeriSelf</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-800/80 border border-zinc-700 text-zinc-400">
                    v2.4
                  </span>
                </div>
              </div>

              {/* Status Indicators */}
              <div className="flex items-center space-x-4 text-xs font-mono">
                <div className="hidden sm:flex items-center space-x-2 px-2.5 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span>CRAWLER MESH: 42 NODES</span>
                </div>
                <div className="flex items-center space-x-2 text-zinc-400 border-l border-zinc-800 pl-4">
                  <span>DEFENSE:</span>
                  <span className="text-emerald-400 font-semibold">ACTIVE</span>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {children}
        </main>
      </body>
    </html>
  );
}
