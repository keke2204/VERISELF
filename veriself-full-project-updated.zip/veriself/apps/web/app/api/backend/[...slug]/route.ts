import { NextRequest, NextResponse } from 'next/server';

const BACKEND_URL = 'http://127.0.0.1:8000';

export async function GET(request: NextRequest, { params }: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await params;
  const targetPath = slug.join('/');
  const searchParams = request.nextUrl.search;
  
  try {
    const res = await fetch(`${BACKEND_URL}/api/v1/${targetPath}${searchParams}`, {
      headers: {
        'Accept': request.headers.get('Accept') || '*/*',
      },
      cache: 'no-store'
    });

    const contentType = res.headers.get('content-type') || 'application/json';
    const body = await res.arrayBuffer();
    
    return new NextResponse(body, {
      status: res.status,
      headers: {
        'Content-Type': contentType,
        'Content-Disposition': res.headers.get('content-disposition') || '',
      },
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Backend service offline or unreachable', details: String(error) },
      { status: 502 }
    );
  }
}

export async function POST(request: NextRequest, { params }: { params: Promise<{ slug: string[] }> }) {
  const { slug } = await params;
  const targetPath = slug.join('/');
  
  try {
    const contentType = request.headers.get('content-type') || '';
    const bodyBuffer = await request.arrayBuffer();
    const nodeBuffer = Buffer.from(bodyBuffer);

    const headers: Record<string, string> = {};
    if (contentType) {
      headers['content-type'] = contentType;
    }
    headers['content-length'] = String(nodeBuffer.length);

    const res = await fetch(`${BACKEND_URL}/api/v1/${targetPath}`, {
      method: 'POST',
      body: nodeBuffer,
      headers,
    });

    const resContentType = res.headers.get('content-type') || 'application/json';
    const resBody = await res.arrayBuffer();

    return new NextResponse(resBody, {
      status: res.status,
      headers: {
        'Content-Type': resContentType,
      },
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Backend service error', details: String(error) },
      { status: 502 }
    );
  }
}
