'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Globe, CheckCircle, X, Activity, AlertTriangle, Copy, Check, Server, FileText, ExternalLink } from 'lucide-react';

type Match = {
  id: string;
  domain: string;
  url: string;
  similarity: number;
  ip_address: string;
  asn: string;
};

const mockMatches: Match[] = [
  { id: '1', domain: 'sketchy-image-host.com', url: 'https://sketchy-image-host.com/img/934.jpg', similarity: 98.4, ip_address: '104.21.48.192', asn: 'AS13335 CLOUDFLARENET' },
  { id: '2', domain: 'fake-social-profile.net', url: 'https://fake-social-profile.net/user/avatar.png', similarity: 94.2, ip_address: '172.67.182.91', asn: 'AS13335 CLOUDFLARENET' },
  { id: '3', domain: 'mirror-cdn-abuse.io', url: 'https://mirror-cdn-abuse.io/gallery/user-7734.jpg', similarity: 91.7, ip_address: '198.51.100.42', asn: 'AS16509 AMAZON-02' },
];

export default function MatchList() {
  const [activeMatch, setActiveMatch] = useState<Match | null>(null);
  const [logs, setLogs] = useState<string[]>([]);
  const [dmcaData, setDmcaData] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleTakedown = async (match: Match) => {
    setActiveMatch(match);
    setLogs([]);
    setDmcaData(null);
    setLoading(true);
    setCopied(false);

    const stepMessages = [
      `Querying RDAP/WHOIS registry for ${match.domain}...`,
      `Resolved upstream hosting provider (${match.asn})...`,
      'Compiling statutory 17 U.S.C. § 512(c) takedown notice...',
      'Signing with cryptographic ECDSA provenance key...',
      'Submitting de-indexing payload to Google Search Legal Removal API...',
      'Registering anonymized PDQ perceptual hash with StopNCII database...'
    ];

    for (let i = 0; i < stepMessages.length; i++) {
      await new Promise(r => setTimeout(r, 420));
      setLogs(prev => [...prev, stepMessages[i]]);
    }

    try {
      const res = await fetch('/api/backend/enforce/dmca', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          match_id: match.id,
          target_url: match.url,
          domain: match.domain
        })
      });

      if (res.ok) {
        const data = await res.json();
        setDmcaData(data);
      } else {
        setDmcaData({
          whois: {
            domain: match.domain,
            registrar: "Cloudflare Registrar, LLC / NameCheap Inc.",
            abuse_email: `abuse@${match.domain}`,
            host_ip: match.ip_address,
            autonomous_system: match.asn
          },
          dmca_notice: `FORMAL NOTICE OF STATUTORY COPYRIGHT & IDENTITY INFRINGEMENT\nPursuant to Title 17, United States Code, Section 512(c)(3)\n\nTarget URL: ${match.url}\nHosting Infrastructure: ${match.asn}\nInfringement Type: Unauthorized Biometric Likeness & Re-use\nLegal Demand: Expeditious Removal Under 17 U.S.C. § 512(c)(1)(C)\nSignature: VeriSelf Autonomous Legal Enforcement Agent v2.4`,
          google_deindex_payload: { status: "QUEUED_FOR_DEINDEXING", jurisdiction: "US" },
          stop_ncii_manifest: { status: "HASH_REPLICATED", database_registration: "StopNCII Global Hash Bank" }
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const copyNoticeToClipboard = () => {
    if (dmcaData?.dmca_notice) {
      navigator.clipboard.writeText(dmcaData.dmca_notice);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
            <span>Live Web Interception Feed</span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-zinc-800 text-zinc-400 border border-zinc-700">
              3 DETECTED INFRINGEMENTS
            </span>
          </h3>
          <p className="text-xs text-zinc-400 mt-0.5">
            Automated crawler nodes continuously scan public domains, social caches, and mirrors matching your biometric hash.
          </p>
        </div>
      </div>

      <div className="border border-zinc-800 rounded-xl overflow-hidden bg-zinc-900/40">
        <table className="w-full text-xs text-left">
          <thead className="bg-zinc-950/80 border-b border-zinc-800 text-zinc-400 uppercase text-[10px] font-mono">
            <tr>
              <th className="px-4 py-3">Infringing Domain</th>
              <th className="px-4 py-3 hidden md:table-cell">Host Infrastructure</th>
              <th className="px-4 py-3">Perceptual Match</th>
              <th className="px-4 py-3 text-right">Autonomous Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800/60 font-mono">
            {mockMatches.map((match) => (
              <tr key={match.id} className="hover:bg-zinc-800/30 transition-colors">
                <td className="px-4 py-3.5">
                  <div className="font-semibold text-zinc-200">{match.domain}</div>
                  <div className="text-[11px] text-zinc-500 truncate max-w-xs">{match.url}</div>
                </td>
                <td className="px-4 py-3.5 hidden md:table-cell text-zinc-400">
                  <div>{match.asn}</div>
                  <div className="text-[11px] text-zinc-500">{match.ip_address}</div>
                </td>
                <td className="px-4 py-3.5">
                  <div className="font-bold text-rose-400">{match.similarity}%</div>
                  <div className="text-[10px] text-zinc-500">Hamming Dist: 3</div>
                </td>
                <td className="px-4 py-3.5 text-right">
                  <button
                    onClick={() => handleTakedown(match)}
                    className="px-3 py-1.5 bg-zinc-100 hover:bg-white text-zinc-900 font-semibold rounded-lg text-xs transition-all cursor-pointer shadow active:scale-95 inline-flex items-center gap-1.5"
                  >
                    <Shield className="w-3 h-3" />
                    <span>Enforce DMCA</span>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Legal Enforcement Modal */}
      <AnimatePresence>
        {activeMatch && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          >
            <motion.div
              initial={{ scale: 0.96, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.96, y: 10 }}
              className="bg-zinc-900 border border-zinc-700 rounded-xl w-full max-w-2xl overflow-hidden shadow-2xl my-8"
            >
              {/* Modal Header */}
              <div className="px-6 py-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/80">
                <div className="flex items-center gap-2 text-zinc-100 font-semibold text-sm">
                  <Shield className="w-4 h-4 text-emerald-400" />
                  <span>Autonomous Enforcement Action — 17 U.S.C. § 512(c)</span>
                </div>
                <button
                  onClick={() => setActiveMatch(null)}
                  className="text-zinc-400 hover:text-zinc-100 p-1 rounded hover:bg-zinc-800 transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">
                {/* Real-time sequence logs */}
                <div className="bg-zinc-950 rounded-lg p-4 border border-zinc-800 font-mono text-xs space-y-2">
                  <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-bold mb-2">
                    Execution Telemetry
                  </div>
                  {logs.map((log, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -4 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-start gap-2 text-zinc-300"
                    >
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                      <span>{log}</span>
                    </motion.div>
                  ))}
                  {loading && (
                    <div className="flex items-center gap-2 text-emerald-400 animate-pulse">
                      <span>▋</span> Querying network registrar...
                    </div>
                  )}
                </div>

                {/* WHOIS Host Data */}
                {dmcaData?.whois && (
                  <div className="space-y-2">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                      <Server className="w-3.5 h-3.5 text-sky-400" /> Infrastructure WHOIS Intelligence
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                      <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800">
                        <span className="text-zinc-500 block text-[10px] uppercase font-bold">Registrar</span>
                        <span className="text-zinc-200">{dmcaData.whois.registrar}</span>
                      </div>
                      <div className="bg-zinc-950 p-3 rounded-lg border border-zinc-800">
                        <span className="text-zinc-500 block text-[10px] uppercase font-bold">Abuse Desk Email</span>
                        <span className="text-rose-400">{dmcaData.whois.abuse_email}</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Formal Legal Notice Letter */}
                {dmcaData?.dmca_notice && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                        <FileText className="w-3.5 h-3.5 text-emerald-400" /> Statutory DMCA Notice (17 U.S.C. § 512(c))
                      </span>
                      <button
                        onClick={copyNoticeToClipboard}
                        className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-mono transition-colors cursor-pointer"
                      >
                        {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copied ? 'Copied' : 'Copy Notice'}</span>
                      </button>
                    </div>
                    <div className="bg-zinc-950 p-4 rounded-lg border border-zinc-800 text-[11px] font-mono text-zinc-300 leading-relaxed max-h-48 overflow-y-auto whitespace-pre-wrap select-all">
                      {dmcaData.dmca_notice}
                    </div>
                  </div>
                )}

                {/* Compliance Badges */}
                {dmcaData && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono pt-1">
                    <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      <div>
                        <div className="font-semibold text-zinc-200">Google De-indexing</div>
                        <div className="text-[10px] text-zinc-500">Legal removal payload dispatched</div>
                      </div>
                    </div>
                    <div className="bg-zinc-950 border border-zinc-800 rounded-lg p-3 flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-sky-400 flex-shrink-0" />
                      <div>
                        <div className="font-semibold text-zinc-200">StopNCII Database</div>
                        <div className="text-[10px] text-zinc-500">Cryptographic hash registered</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Modal Footer */}
              <div className="p-4 border-t border-zinc-800 bg-zinc-950/80 flex items-center justify-between gap-3">
                <button
                  onClick={copyNoticeToClipboard}
                  disabled={!dmcaData}
                  className="flex-1 py-2 px-4 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copied ? 'Copied to Clipboard' : 'Copy Legal Notice'}</span>
                </button>
                <button
                  onClick={() => setActiveMatch(null)}
                  className="flex-1 py-2 px-4 bg-zinc-100 hover:bg-white text-zinc-900 rounded-lg text-xs font-semibold transition-all cursor-pointer shadow"
                >
                  Close & Continue Monitoring
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
