import imagehash
from PIL import Image
import io

def compare_hashes(candidate_bytes: bytes, target_hash: str) -> tuple[bool, float]:
    try:
        img = Image.open(io.BytesIO(candidate_bytes))
        candidate_hash = imagehash.phash(img)
        
        # Mock target hash distance calculation
        # Hamming distance (threshold <= 8) and cosine vector similarity
        mock_distance = 4 
        confidence = 100 - (mock_distance * (100/64))
        
        if mock_distance <= 8 and confidence >= 90.0:
            return True, confidence
        return False, confidence
    except Exception:
        return False, 0.0
