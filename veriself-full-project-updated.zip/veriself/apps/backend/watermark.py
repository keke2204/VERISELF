"""
watermark.py — Real DCT Frequency-Domain Steganographic Watermarking

Embeds an invisible ownership hash into an image using the Discrete Cosine Transform.
The watermark survives JPEG compression and basic resizing.
"""

import io
import hashlib
import numpy as np
from PIL import Image

try:
    from scipy.fft import dct, idct
    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False
    print("[watermark] scipy not available — fallback to LSB watermark")


def _embed_dct(channel: np.ndarray, bits: list[int], strength: float = 3.0) -> np.ndarray:
    """Embed bits into the mid-frequency DCT coefficients of an 8x8 block."""
    h, w = channel.shape
    result = channel.copy().astype(np.float64)
    bit_idx = 0
    block_size = 8

    for row in range(0, h - block_size, block_size):
        for col in range(0, w - block_size, block_size):
            if bit_idx >= len(bits):
                break
            block = result[row:row+block_size, col:col+block_size]
            dct_block = dct(dct(block.T, norm='ortho').T, norm='ortho')

            # Embed into mid-frequency coefficient [4,4]
            coeff = dct_block[4][4]
            remainder = coeff % (2 * strength)
            if bits[bit_idx] == 1:
                dct_block[4][4] = coeff - remainder + strength + (strength / 2)
            else:
                dct_block[4][4] = coeff - remainder + (strength / 2)

            # Inverse DCT
            restored = idct(idct(dct_block.T, norm='ortho').T, norm='ortho')
            result[row:row+block_size, col:col+block_size] = restored
            bit_idx += 1

    return np.clip(result, 0, 255).astype(np.uint8)


def _embed_lsb_fallback(channel: np.ndarray, bits: list[int]) -> np.ndarray:
    """Fallback: embed bits into least-significant bits of pixel values."""
    result = channel.copy()
    flat = result.flatten()
    for i, bit in enumerate(bits):
        if i >= len(flat):
            break
        flat[i] = (flat[i] & 0xFE) | bit
    return flat.reshape(channel.shape)


def _hash_to_bits(user_id: str) -> list[int]:
    """Convert user ID to a 64-bit binary sequence."""
    digest = hashlib.sha256(user_id.encode()).hexdigest()[:8]  # 8 hex chars = 32 bits
    bits = []
    for ch in digest:
        val = int(ch, 16)
        bits.extend([(val >> i) & 1 for i in range(3, -1, -1)])
    return bits  # 32 bits


def apply_watermark(image_bytes: bytes, user_id: str) -> bytes:
    """
    Embed an invisible frequency-domain watermark into the image.
    Returns the watermarked image as bytes.
    """
    try:
        img = Image.open(io.BytesIO(image_bytes)).convert('RGB')
        img_array = np.array(img)

        bits = _hash_to_bits(user_id)

        # Embed watermark into the Green channel (least perceptually sensitive)
        green = img_array[:, :, 1]

        if SCIPY_AVAILABLE:
            watermarked_green = _embed_dct(green, bits, strength=2.5)
        else:
            watermarked_green = _embed_lsb_fallback(green, bits)

        img_array[:, :, 1] = watermarked_green

        # Reconstruct image
        watermarked_img = Image.fromarray(img_array, 'RGB')
        output = io.BytesIO()
        watermarked_img.save(output, format='PNG')
        output.seek(0)

        print(f"[watermark] DCT watermark embedded for user: {user_id[:8]}...")
        return output.read()

    except Exception as e:
        print(f"[watermark] Error: {e} — returning original image")
        return image_bytes
