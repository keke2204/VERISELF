"""
pipeline.py — Biometric Ingestion & Watermark Pipeline
"""

import io
import hashlib
import numpy as np
import imagehash
from PIL import Image
from watermark import apply_watermark

try:
    from database import save_identity
    DB_AVAILABLE = True
except Exception:
    DB_AVAILABLE = False

def compute_hashes(image_bytes: bytes):
    img = Image.open(io.BytesIO(image_bytes))
    phash = str(imagehash.phash(img))
    dhash = str(imagehash.dhash(img))
    return phash, dhash

def extract_face_embeddings(image_bytes: bytes) -> list:
    """
    Computes a deterministic 512-D unit-sphere embedding from image statistics.
    Drop-in replaceable with facenet-pytorch or InsightFace when GPU is available.
    """
    try:
        img = Image.open(io.BytesIO(image_bytes)).convert('RGB').resize((160, 160))
        arr = np.array(img).astype(np.float32) / 255.0
        flat = arr.flatten()
        block = max(1, len(flat) // 512)
        embedding = [float(np.mean(flat[i * block:(i + 1) * block])) for i in range(512)]
        norm = np.linalg.norm(embedding) + 1e-8
        embedding = [v / norm for v in embedding]
        return embedding
    except Exception as e:
        print(f"[pipeline] Embedding error: {e}")
        return []

def process_biometric_ingestion(job_id: str, image_bytes: bytes):
    print(f"[pipeline] Starting ingestion for job {job_id}")

    embeddings = extract_face_embeddings(image_bytes)
    phash, dhash = compute_hashes(image_bytes)

    print(f"[pipeline] {len(embeddings)}-D embedding computed")
    print(f"[pipeline] pHash={phash} | dHash={dhash}")

    # Persist to PostgreSQL if DB is available
    if DB_AVAILABLE and embeddings:
        try:
            save_identity(job_id, phash, dhash, embeddings)
        except Exception as e:
            print(f"[pipeline] DB save skipped: {e}")

    # Apply DCT watermark
    watermarked = apply_watermark(image_bytes, job_id)
    print(f"[pipeline] Watermark applied. Pipeline complete for {job_id}")
    return {"job_id": job_id, "phash": phash, "dhash": dhash, "embedding_dims": len(embeddings)}
