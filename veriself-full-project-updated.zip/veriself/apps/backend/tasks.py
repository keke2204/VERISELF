from celery_app import celery_instance
from crawler import crawl_target_url
from enforcement import trigger_takedown

@celery_instance.task
def run_crawler_task(target_url: str):
    crawl_target_url(target_url)

@celery_instance.task
def execute_takedown_task(match_id: str, target_url: str):
    trigger_takedown(match_id, target_url)
