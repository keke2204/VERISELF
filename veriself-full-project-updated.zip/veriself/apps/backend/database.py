"""
database.py — PostgreSQL + pgvector connection and schema setup
Uses psycopg2 to store face embeddings and perceptual hashes.
"""

import os
import json
import psycopg2
from psycopg2.extras import RealDictCursor

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://user:password@localhost:5432/veriself")

def get_conn():
    return psycopg2.connect(DATABASE_URL)

def init_db():
    """Create tables and enable pgvector extension."""
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
            cur.execute("""
                CREATE TABLE IF NOT EXISTS identities (
                    id          SERIAL PRIMARY KEY,
                    job_id      TEXT UNIQUE NOT NULL,
                    phash       TEXT,
                    dhash       TEXT,
                    embedding   vector(512),
                    created_at  TIMESTAMP DEFAULT NOW()
                );
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS matches (
                    id              SERIAL PRIMARY KEY,
                    identity_job_id TEXT REFERENCES identities(job_id),
                    source_url      TEXT,
                    domain          TEXT,
                    similarity      FLOAT,
                    status          TEXT DEFAULT 'pending',
                    detected_at     TIMESTAMP DEFAULT NOW()
                );
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS takedowns (
                    id              SERIAL PRIMARY KEY,
                    match_id        INT REFERENCES matches(id),
                    whois_info      TEXT,
                    dmca_notice     TEXT,
                    status          TEXT DEFAULT 'dispatched',
                    dispatched_at   TIMESTAMP DEFAULT NOW()
                );
            """)
            conn.commit()
            print("[db] Schema initialized.")
    except Exception as e:
        print(f"[db] Init error: {e}")
        conn.rollback()
    finally:
        conn.close()

def save_identity(job_id: str, phash: str, dhash: str, embedding: list):
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO identities (job_id, phash, dhash, embedding) VALUES (%s, %s, %s, %s::vector) ON CONFLICT (job_id) DO NOTHING;",
                (job_id, phash, dhash, json.dumps(embedding))
            )
            conn.commit()
            print(f"[db] Saved identity {job_id}")
    except Exception as e:
        print(f"[db] Save error: {e}")
        conn.rollback()
    finally:
        conn.close()

def get_all_identities():
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("SELECT job_id, phash, dhash, created_at FROM identities ORDER BY created_at DESC;")
            return cur.fetchall()
    except Exception as e:
        print(f"[db] Fetch error: {e}")
        return []
    finally:
        conn.close()

def save_match(job_id: str, url: str, domain: str, similarity: float):
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO matches (identity_job_id, source_url, domain, similarity) VALUES (%s, %s, %s, %s) RETURNING id;",
                (job_id, url, domain, similarity)
            )
            match_id = cur.fetchone()[0]
            conn.commit()
            return match_id
    except Exception as e:
        print(f"[db] Match save error: {e}")
        conn.rollback()
        return None
    finally:
        conn.close()

def get_matches(job_id: str = None):
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            if job_id:
                cur.execute("SELECT * FROM matches WHERE identity_job_id = %s ORDER BY detected_at DESC;", (job_id,))
            else:
                cur.execute("SELECT * FROM matches ORDER BY detected_at DESC LIMIT 50;")
            return cur.fetchall()
    except Exception as e:
        print(f"[db] Matches fetch error: {e}")
        return []
    finally:
        conn.close()

def save_takedown(match_id: int, whois_info: str, dmca_notice: str, status: str = "dispatched"):
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO takedowns (match_id, whois_info, dmca_notice, status) VALUES (%s, %s, %s, %s);",
                (match_id, whois_info, dmca_notice, status)
            )
            conn.commit()
    except Exception as e:
        print(f"[db] Takedown save error: {e}")
        conn.rollback()
    finally:
        conn.close()

def get_takedowns():
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("""
                SELECT t.*, m.source_url, m.domain, m.similarity
                FROM takedowns t
                JOIN matches m ON t.match_id = m.id
                ORDER BY t.dispatched_at DESC LIMIT 50;
            """)
            return cur.fetchall()
    except Exception as e:
        print(f"[db] Takedowns fetch error: {e}")
        return []
    finally:
        conn.close()
