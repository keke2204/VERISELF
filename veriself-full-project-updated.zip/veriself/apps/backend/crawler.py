from playwright.sync_api import sync_playwright
import httpx
from matcher import compare_hashes

def crawl_target_url(target_url: str):
    print(f"Crawling {target_url}...")
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(target_url, timeout=30000)
            
            image_elements = page.query_selector_all("img")
            for img in image_elements:
                src = img.get_attribute("src")
                if src and src.startswith("http"):
                    # Stream candidate image buffers via httpx
                    try:
                        resp = httpx.get(src, timeout=10)
                        if resp.status_code == 200:
                            is_match, score = compare_hashes(resp.content, "mock_db_hash")
                            if is_match:
                                print(f"Match found at {src} with confidence {score}%")
                    except Exception as e:
                        print(f"Failed to fetch {src}: {e}")
            browser.close()
    except Exception as e:
        print(f"Crawl failed: {e}")
